#ifndef __UDA1380_H__
#define __UDA1380_H__

/* Includes ------------------------------------------------------------------*/
#include "lpc17xx_i2c.h"
#include "lpc17xx_clkpwr.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_libcfg.h"
#include "LPC17xx.h"


int32_t  UDA1380Init(void);


#endif  // __UDA1380_H__







