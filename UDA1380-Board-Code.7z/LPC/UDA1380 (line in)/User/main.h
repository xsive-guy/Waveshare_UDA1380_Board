/****************************************Copyright (c)****************************************************
**                            Guangzhou ZHIYUAN electronics Co.,LTD.
**
**                                 http://www.embedtools.com
**
**--------------File Info---------------------------------------------------------------------------------
** File name:           main.c
** Last modified Date:  2009-07-30
** Last Version:        V1.01
** Descriptions:        The main() function example template
**
**--------------------------------------------------------------------------------------------------------
** Created by:          LinEnqiang
** Created date:        2009-06-12
** Version:             V1.00
** Descriptions:        I2S_WAVPlay_Polling���Գ���
**
**--------------------------------------------------------------------------------------------------------
** Modified by:         Liangbaoqiong
** Modified date:       2009-07-20
** Version:             V1.00
** Descriptions:        �Գ���ķ���Լ�ע��������������������
**
** Rechecked by:        CaiHua
*********************************************************************************************************/
#ifndef __MAIN_H 
#define __MAIN_H

#ifdef __cplusplus
    extern "C" {
#endif
//#include    "config.h"
//#include    "LPC1700PinCfg.h"




/*********************************************************************************************************
  ������궨��
*********************************************************************************************************/
      

/* 
 *  Ԥ�����I2S��ʼ�������ļ���
 */
//#define	  SAMPLERATE            22000
//#define   BIT_N			16
//#define	  CHANNEL_N		2
//#define	  I2SBITRATE		(SAMPLERATE *  BIT_N *  CHANNEL_N)
//#define   I2STXRATE_VAL		(FPCLK_FREQ / I2SBITRATE - 1)



#ifdef __cplusplus
	}
#endif 
  
#endif                                                                  /* __MAIN_H                     */
/*********************************************************************************************************
  End Of File
*********************************************************************************************************/
